﻿namespace MP4.Custom;

public enum CouponStatus
{
    Win,
    Lose,
    InProgress,
}