﻿namespace MP3.Multi_aspect;

public class JuniorDeveloper : DeveloperExperience
{
    public override string ToString()
    {
        return base.ToString() + "Junior";
    }
}