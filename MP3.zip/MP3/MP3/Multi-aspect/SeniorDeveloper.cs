﻿namespace MP3.Multi_aspect;

public class SeniorDeveloper : DeveloperExperience
{
    public override string ToString()
    {
        return base.ToString() +  "Senior";
    }
}