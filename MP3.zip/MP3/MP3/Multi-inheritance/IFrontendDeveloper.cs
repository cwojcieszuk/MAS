﻿namespace MP3.Multi;

public interface IFrontendDeveloper
{
    public void Code();
}