﻿namespace MP5.DTO;

public class GetAllBetsDTO
{
    public int IdBet { get; set; }
    public string Category { get; set; }
    public double Rate { get; set; }
    public string BetType { get; set; }
    public string Name { get; set; }
}