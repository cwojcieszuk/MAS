﻿namespace MP5.Constants;

public class BetTypeConstants
{
    public static string SportsBet = "SportsBet";
    public static string EventsBet = "EventsBet";
}