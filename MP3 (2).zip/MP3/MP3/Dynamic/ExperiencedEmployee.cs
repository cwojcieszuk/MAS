﻿namespace MP3.Dynamic;

public class ExperiencedEmployee : EmployeeExperience
{
    public override string ToString()
    {
        return base.ToString() + "Experienced";
    }
}