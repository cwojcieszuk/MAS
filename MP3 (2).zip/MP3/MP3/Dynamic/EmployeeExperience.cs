﻿namespace MP3.Dynamic;

public abstract class EmployeeExperience
{
    public override string ToString()
    {
        return "Experience: ";
    }
}