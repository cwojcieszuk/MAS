﻿namespace MP3.Overlapping;

public enum EmployeeType
{
    Employee,
    Developer,
    Tester,
}