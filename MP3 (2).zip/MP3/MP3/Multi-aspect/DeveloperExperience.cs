﻿namespace MP3.Multi_aspect;

public abstract class DeveloperExperience
{
    public override string ToString()
    {
        return "Experience: ";
    }
}